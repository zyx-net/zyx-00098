# Release Schedule Summary
Schedule ID: SCHED-20260612073530-92bf9ffd
Generated at: 2026-06-12T07:35:30Z

## Overview
- Total windows: 3
- Total waves: 3
- Components scheduled: 4
- Components unscheduled: 0

## Windows
### [OPEN] June - Dev Continuous (WIN-2026-JUN-DEV)
- Time: 2026-06-01T00:00:00Z -> 2026-06-30T23:59:59Z (UTC)
- Allowed environments: dev, test

### [OPEN] June Week 1 - Business Hours (WIN-2026-JUN-W1)
- Time: 2026-06-15T09:00:00Z -> 2026-06-15T17:00:00Z (UTC)
- Capacity: 3
- Allowed environments: staging, production
- Components (3):
  * common-utils v2.3.1 (wave: Infrastructure)
  * auth-service v1.5.0 (wave: Business Services)
  * order-service v3.1.0 (wave: Customer Facing)

### [OPEN] June Week 2 - Extended (WIN-2026-JUN-W2)
- Time: 2026-06-22T08:00:00Z -> 2026-06-22T20:00:00Z (UTC)
- Capacity: 5
- Allowed environments: staging, production
- Freeze periods:
  * Black Friday Eve: 2026-06-22T12:00:00Z -> 2026-06-22T13:00:00Z - Quarter-end review moratorium
- Components (1):
  * payment-service v2.0.2 (wave: Customer Facing)

## Waves
### [1] Infrastructure (WAVE-1)
- Shared libraries and core services
- Components (1):
  * common-utils v2.3.1 (window: June Week 1 - Business Hours)

### [2] Business Services (WAVE-2)
- Business logic microservices
- Components (1):
  * auth-service v1.5.0 (window: June Week 1 - Business Hours)

### [3] Customer Facing (WAVE-3)
- End-user and public-facing services
- Components (2):
  * order-service v3.1.0 (window: June Week 1 - Business Hours)
  * payment-service v2.0.2 (window: June Week 2 - Extended)
